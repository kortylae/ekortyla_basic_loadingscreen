author 'E.Kortyla'

lua54 'yes'

files {
    'html/index.html',
    'html/ekortyla.css',
    'html/ek.png',
    'html/ek.mp3'
}

loadscreen 'html/index.html'

loadscreen_manual_shutdown "yes"